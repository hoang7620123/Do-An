<div>
    <p>Chào anh/chị,</p>
    <p>Gille đã nhận được thư của anh/chị.<br/> 
    Chúng tôi sẽ liên lạc với anh/chị trong thời gian sớm nhất.</p>
    <p>Trân trọng,</p>
</div>