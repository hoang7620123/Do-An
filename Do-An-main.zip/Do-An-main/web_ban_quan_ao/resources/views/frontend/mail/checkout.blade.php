<div>
    <p>Có khách hàng tên: {{$donhang['hoten']}}<b></b>. Email: {{$donhang['email']}}<b></b>. Số điện thoại: {{$donhang['phone']}}<b></b> </p>
    <p>Đã đặt hàng tại Gillee Shop:</p>
 </div>