<div>
    <p>Có khách hàng tên: <b>{{ $data['name'] }}</b>. Email: <b>{{ $data['email'] }}</b>. Số điện thoại: <b>{{ $data['phone'] }}</b> </p>
    <p>Liên hệ cho bạn với nội dung: {{ $data['message'] }}</p>
 </div>