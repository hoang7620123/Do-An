# ĐỒ ÁN CƠ SỞ NGÀNH - NHÓM 6

## Khoa Công Nghệ Thông Tin - Học Viện Hàng Không Việt Nam  

### 📌 Đề tài: **Xây dựng Web thời trang sử dụng công nghệ laravel**  

---

## 👨‍💻 Thành viên nhóm:
- Phạm Minh Hoàng  
- Lê Đăng Khoa  
- Nguyễn Anh Tuấn  
- Hà Văn Sáng  

---

## 🔧 Công nghệ sử dụng:
- Laravel  
- MySQL  
- PHP 

